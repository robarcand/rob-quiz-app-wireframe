# RobQuizApp

**This app is a simple, 10-question quiz on a few of the core components that make up HTML. It was created with HTML, CSS, JavaScript, and jQuery, and represents an early attempt to move away from writing small, single-use Javascript and jQuery functions to architecting larger software applications. Enjoy!**

URL : https://thinkful-ei-heron.github.io/RobQuizAppRevision/